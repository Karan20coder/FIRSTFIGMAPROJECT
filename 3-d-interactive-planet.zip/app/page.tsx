import { PlanetEmbed } from '@/components/planet-embed'

export default function Page() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur supports-[backdrop-filter]:bg-slate-950/30">
        <div className="w-full px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Karan's Figma Planets
              </h1>
              <p className="mt-2 text-slate-400">
                Interactive 3D planetary exploration experience
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="w-full px-4 py-12 sm:px-6 lg:px-8">
        {/* Main Visualization - Full Width */}
        <div className="mb-8 w-full">
          <div className="h-screen w-full overflow-hidden rounded-xl border border-slate-800 bg-slate-900/50 shadow-2xl">
            <PlanetEmbed />
          </div>
        </div>

        {/* Instructions Section */}
        <div className="mx-auto max-w-4xl space-y-8">
          <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-8 backdrop-blur">
            <h2 className="mb-6 text-2xl font-bold text-white">How to Explore</h2>
            <div className="space-y-6">
              {/* Step 1 */}
              <div className="flex gap-4">
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-blue-500 font-bold text-white">
                  1
                </div>
                <div>
                  <h3 className="font-semibold text-white">Click the Expand Button</h3>
                  <p className="mt-1 text-slate-400">
                    Look for the expand icon in the top-right corner of the visualization to enter fullscreen mode for a better viewing experience.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex gap-4">
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-blue-500 font-bold text-white">
                  2
                </div>
                <div>
                  <h3 className="font-semibold text-white">Click on Other Planets</h3>
                  <p className="mt-1 text-slate-400">
                    The interface includes multiple planets. Click on different planetary elements to smoothly transition and explore each planet.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-6 text-center backdrop-blur">
              <div className="text-3xl font-bold text-blue-400">180°</div>
              <p className="mt-2 text-sm text-slate-400">Half rotation view</p>
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-6 text-center backdrop-blur">
              <div className="text-3xl font-bold text-blue-400">5+</div>
              <p className="mt-2 text-sm text-slate-400">Interactive planets</p>
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-6 text-center backdrop-blur">
              <div className="text-3xl font-bold text-blue-400">60FPS</div>
              <p className="mt-2 text-sm text-slate-400">Smooth performance</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
