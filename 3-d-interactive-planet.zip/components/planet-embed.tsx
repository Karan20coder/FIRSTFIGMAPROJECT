'use client'

export function PlanetEmbed() {
  return (
    <div className="w-full h-full bg-gradient-to-b from-slate-950 to-slate-900 rounded-xl overflow-hidden shadow-2xl">
      <iframe
        src="https://embed.figma.com/proto/gqxBo6HhbB79b6jqon3C3H/3D-Interactive-Planet-Animation?node-id=1-18&p=f&scaling=contain&content-scaling=fixed&page-id=0%3A1&starting-point-node-id=0%3A9&embed-host=share"
        className="w-full h-full border-none"
        allowFullScreen
      />
    </div>
  )
}
